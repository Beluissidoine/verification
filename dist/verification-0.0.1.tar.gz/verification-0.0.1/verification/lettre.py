def demander_lettre():
    reponse_nom = ""
    while reponse_nom == "" :
        reponse_nom = input(" Quel est ton nom ? : ")
    return reponse_nom

